#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# ## Задание

# Исходные материалы:

# 1. выгрузки продаж за 4 квартала (2 квартал 2023 года – только прошедшие дни)
# 2. справочник кураторов (каждый магазин закреплен за куратором)
# 3. справочник категорийных менеджеров (подкатегории закреплены за категорийными менеджерами)
# 4. выгрузка количества чеков

# С использованием Python нужно создать csv-файлы и на основании этих файлов в Excel с использованием PowerQuery
# создать дашборды:

# 1. линейная диаграмма, показывающая изменение товарооборота по кураторам по месяцам за 2 года
# 2. столбиковая диаграмма, показывающая изменение по категорийным менеджерам товарооборота по месяцам
# 3. столбиковая диаграмма, показывающая изменение среднего чека (рассчитывается как товарооборот, деленный на трафик)
# по кураторам за 2 года по месяцам
# 4. столбиковая диаграмма, показывающая прирост трафика по кураторам по месяцам (год к году)

# Все расчеты должны быть выполнены на стороне Python, использование расчетных полей на стороне Excel не допускается.
# Задание предоставляется в виде:

# 1. csv-файлов, использованных для визуализации отчетов в Excel (4 файла, по одному для каждой диаграммы)
# 2. кода Python, выполняющего предобработку данных (формат .py)
# 3. Excel-файла с дашбордами


import pandas as pd
import numpy as np
import bamboolib as bam

# df_q1_22 = pd.read_excel('/mnt/m/Spar/1 XLSX/1 квартал 2022.xlsx')
# df_q1_23 = pd.read_excel('/mnt/m/Spar/1 XLSX/1 квартал 2023.xlsx')
# df_q2_22 = pd.read_excel('/mnt/m/Spar/1 XLSX/2 квартал 2022.xlsx')
# df_q2_23 = pd.read_excel('/mnt/m/Spar/1 XLSX/2 квартал 2023.xlsx')

# df_catman = pd.read_excel('/mnt/m/Spar/1 XLSX/Категорийный менеджер.xlsx')
# df_checks = pd.read_excel('/mnt/m/Spar/1 XLSX/Чеки.xlsx')
# df_cour = pd.read_excel('/mnt/m/Spar/1 XLSX/Кураторы.xlsx')

# df_q1_22 = df_q1_22.loc[1:]
# df_q1_23 = df_q1_23.loc[1:]
# df_q2_22 = df_q2_22.loc[1:]
# df_q2_23 = df_q2_23.loc[1:]
# df_checks = df_checks.loc[1:]

# df_q = pd.concat([df_q1_22, df_q1_23, df_q2_22, df_q2_23])

# df_q = df_q.reset_index()
# df_q['Магазин'] = pd.to_numeric(df_q['Магазин'], downcast='integer', errors='coerce')
# df_checks = df_checks.reset_index()
# df_checks['Магазин'] = pd.to_numeric(df_checks['Магазин'], downcast='integer', errors='coerce')
# df_q.to_feather('/mnt/m/Spar/2 CSV/all q.feather')
# df_catman.to_feather('/mnt/m/Spar/2 CSV/Категорийный менеджер.feather')
# df_checks.to_feather('/mnt/m/Spar/2 CSV/Чеки.feather')
# df_cour.to_feather('/mnt/m/Spar/2 CSV/Кураторы.feather')

df_q = pd.read_feather('/mnt/m/Spar/2 CSV/all q.feather')

df_catman = pd.read_feather('/mnt/m/Spar/2 CSV/Категорийный менеджер.feather')
df_checks = pd.read_feather('/mnt/m/Spar/2 CSV/Чеки.feather')
df_cour = pd.read_feather('/mnt/m/Spar/2 CSV/Кураторы.feather')

 ### линейная диаграмма, показывающая изменение товарооборота по кураторам по месяцам за 2 года
    
df_cour_mo = df_cour.merge(df_q, on='Магазин')
df_cour_mo['mo'] = df_cour_mo.Дата.astype('datetime64[M]')
df_cour_mo = df_cour_mo.groupby(['mo', 'Куратор'], as_index=False)['Продажи, руб'].sum()
df_cour_mo.to_csv('/mnt/m/Spar/3 Results/1_question_df_cour_mo.csv')


### столбиковая диаграмма, показывающая изменение по категорийным менеджерам товарооборота по месяцам

df_catman_mo = df_catman.merge(df_q, on='Подкатегория товаров')
df_catman_mo['mo'] = df_catman_mo.Дата.astype('datetime64[M]')
df_catman_mo = df_catman_mo.groupby(['mo', 'КМ'], as_index=False)['Продажи, руб'].sum()
df_catman_mo.to_csv('/mnt/m/Spar/3 Results/2_question_df_catman_mo.csv')


### столбиковая диаграмма, показывающая изменение среднего чека
# (рассчитывается как товарооборот, деленный на трафик) по кураторам за 2 года по месяцам

df_q['mo'] = df_q.Дата.astype('datetime64[M]')
df_q_mo = df_q.groupby(['mo', 'Магазин'], as_index=False)['Продажи, руб'].sum()
df_q_mo['Магазин'] = pd.to_numeric(df_q_mo['Магазин'], downcast='integer', errors='coerce')

df_checks['mo'] = df_checks.Дата.astype('datetime64[M]')
df_checks_mo = df_checks.groupby(['mo', 'Магазин'], as_index=False)['Трафик'].sum()
df_checks_mo['Магазин'] = pd.to_numeric(df_checks_mo['Магазин'], downcast='integer', errors='coerce')

# df_cour
import pandas as pd; import numpy as np
# Step: Change data type of Магазин to Integer
df_checks_mo['Магазин'] = pd.to_numeric(df_checks_mo['Магазин'], downcast='integer', errors='coerce')

df_cour_check_mo_shop = df_checks_mo.merge(df_q_mo, on=['Магазин', 'mo']).merge(df_cour, on='Магазин')
df_cour_check_mo = df_cour_check_mo_shop.groupby(['Куратор', 'mo'], as_index=False).agg({'Продажи, руб':'sum', 'Трафик':'sum'})

import pandas as pd; import numpy as np
df_cour_check_mo = df_cour_check_mo.reset_index()
import pandas as pd; import numpy as np
# Step: Rename column
df_cour_check_mo = df_cour_check_mo.rename(columns={'Продажи, руб': 'rev', 'Трафик': 'traffic'})

df_cour_check_mo['mean_check'] = round(df_cour_check_mo.rev / df_cour_check_mo.traffic, 2)

df_cour_check_mo.to_csv('/mnt/m/Spar/3 Results/3_question_df_cour_check_mo_mean.csv')


### столбиковая диаграмма, показывающая прирост трафика по кураторам по месяцам (год к году)

df_tr = df_cour.merge(df_checks_mo)

df_tr_mo = df_tr.groupby(['mo', 'Куратор'], as_index=False).Трафик.sum()
# df_tr_mo['ye'] = df_tr_mo.mo.astype('datetime64[Y]')
df_tr_mo['mo_num'] = df_tr_mo.mo.dt.month

df_tr_mo['pct_change'] = df_tr_mo.groupby(['mo_num', 'Куратор']).Трафик.transform('pct_change')
import pandas as pd; import numpy as np
# Step: Keep rows where pct_change is not missing
df_tr_mo = df_tr_mo.loc[df_tr_mo['pct_change'].notna()]

df_tr_mo.to_csv('/mnt/m/Spar/3 Results/4_question_df_tr_mo.csv')

